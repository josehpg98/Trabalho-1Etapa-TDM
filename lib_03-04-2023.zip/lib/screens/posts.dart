import "package:flutter/cupertino.dart";
import "package:flutter/material.dart";
import "package:pteste1/models/post.dart";
import "package:pteste1/screens/post_detail.dart";
//import ".../services/http_service.dart";
import 'package:pteste1/service/http_service.dart';

class Posts extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return PostsState();
  }
}

class PostsState extends State<Posts> {
  final HttpService httpService = HttpService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                colors: [
                  Colors.deepPurple,
                  Colors.pink,
                ],
                begin: const FractionalOffset(0.0, 0.0),
                end: const FractionalOffset(1.0, 0.0),
                stops: [0.0, 1.0],
                tileMode: TileMode.clamp),
          ),
        ),
        leading: const Icon(Icons.local_post_office),
        title: Text("Posts"),

      ),
      body: FutureBuilder(
        future: httpService.getPosts(),
        builder: (BuildContext context, AsyncSnapshot<List<Post>> snapshot) {
          if (snapshot.hasData) {
            List<Post>? posts = snapshot.data;
            return ListView(
              children: posts!
                  .map((Post post) => Card(
                        child: ListTile(
                          leading: const Icon(Icons.message_outlined),
                          title: Text(post.title),
                          subtitle: Text("Usuário: " + post.userID.toString()),
                          onTap: () => Navigator.of(context).push(
                              MaterialPageRoute(
                                  builder: (context) =>
                                      PostDetail(post: post))),
                        ),
                      ))
                  .toList(),
            );
          } else {
            return Center(child: CircularProgressIndicator());
          }
        },
      ),
    );
  }
}
