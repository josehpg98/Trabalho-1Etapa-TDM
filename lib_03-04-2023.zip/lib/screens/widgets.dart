//post.dart na pasta screens

import 'package:flutter/material.dart';

class Widgets extends StatefulWidget{
  @override
  State<StatefulWidget> createState() {
    return WidgetsState();
  }
}

class WidgetsState extends State<Widgets>{
  @override
  Widget build(BuildContext context) {
   return Scaffold(
     appBar: AppBar(
       flexibleSpace: Container(
         decoration: BoxDecoration(
           gradient: LinearGradient(
               colors: [
                 Colors.pink,
                 Colors.pink,
               ],
               begin: const FractionalOffset(0.0, 0.0),
               end: const FractionalOffset(1.0, 0.0),
               stops: [0.0, 1.0],
               tileMode: TileMode.clamp),
         ),
       ),
       title: Text("Widgets: ClipRRect e Image.network"),

     ),
     body:
     Container(
       child: InkWell(
         onTap: () {},
         child: ClipRRect(
           borderRadius: BorderRadius.circular(35.0),
           child: Image.network('https://docs.flutter.dev/assets/images/dash/dash-fainting.gif'),
         ),
       ),
     ),
   );
  }

}