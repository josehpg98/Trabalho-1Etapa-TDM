import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'tarefadao.dart';
import 'compradao.dart';

const String tableSql2 =  'CREATE TABLE cursos ('
                        + 'id INTEGER PRIMARY KEY, '
                        + 'descricao TEXT, '
                        + 'info TEXT )';

const String tableSQL = 'CREATE TABLE compras ('
    +'id INTEGER PRIMARY KEY,'
    +'nome TEXT, '
    +'quantidade TEXT, '
    +'fabricante TEXT, '
    +'local TEXT)';

  Future<Database> getDatabase() async {
    final String path = join(await getDatabasesPath(), 'dbtarefas.db');
    return openDatabase(path,
        onCreate: (db, version) {
          db.execute(TarefaDao.tableSQL);
          db.execute(CompraDao.tableSQL);
          //db.execute(CompraDao.tableSQL);
        },
        onUpgrade: (db, oldVersion, newVersion) async{
          var batch = db.batch();
          print("Versão antiga: " + oldVersion.toString());
          print("Versão nova: " + newVersion.toString());

          if (newVersion == 2){
            //batch.execute(tableSql2);
            //trocar a versão da DB para 2 para poder gerar a tabela de compras
            batch.execute(tableSQL);
          }
          await batch.commit();
        },
        version: 2,
        onDowngrade: onDatabaseDowngradeDelete
    );
  }
