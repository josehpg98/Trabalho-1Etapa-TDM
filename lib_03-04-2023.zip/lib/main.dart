import 'package:flutter/material.dart';
import 'menu.dart';


void main() {
  runApp(
    MaterialApp(



      title: 'Trabalho01',
      theme: ThemeData(primarySwatch: Colors.deepPurple),
      darkTheme: ThemeData(brightness: Brightness.dark, primarySwatch: Colors.deepPurple),
      themeMode: ThemeMode.light,
      home: MenuOptions()
    )
  );
  //TarefaDao dao = TarefaDao();
  //dao.save(Tarefa(0, "teste tarefa", "obs da tarefa")).then((value) {
  //  dao.findAll().then((tarefa) => debugPrint(tarefa.toString()));
  //});

}



